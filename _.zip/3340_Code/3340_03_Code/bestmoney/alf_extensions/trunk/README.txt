How to build and deploy AMP
---------------------------
1) Set variables in build.properties to point to your Alfresco installation and your Alfresco SDK
2) Make a copy of the original alfresco.war called alfresco.war.bak in the same webapps directory (the build script uses it)
3) Stop Alfresco
4) Run the deploy-alfresco-amp to test Alfresco Repository AMP extensions
5) Run the deploy-share-jar to test Alfresco Share JAR extensions
6) Start Alfresco




