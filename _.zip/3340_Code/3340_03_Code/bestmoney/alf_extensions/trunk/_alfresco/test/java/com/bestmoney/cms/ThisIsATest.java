package com.bestmoney.cms;

import org.junit.Test;

public class ThisIsATest {
    @Test
    public void testThis() {
        System.out.println("Running some tests...");
    }
}