To deploy the document management code for chapter 6 do as follows
---------------------------------------------------------------------
1) Update the paths in build.properties
2) Stop Alfresco
3) Run the deploy-alfresco-amp ant target
4) Run the deploy-share-jar ant target
5) Start Alfresco

JavaScript Code
--------------------------------------------------------------------
The JavaScripts that were developed in chapter 6 can be found in the
3340_06_Code\bestmoney\alf_extensions\trunk\_alfresco\source\javascript
directory.