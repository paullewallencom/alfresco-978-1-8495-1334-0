To deploy the document management code for this chapter do as follows
---------------------------------------------------------------------
1) Update the paths in build.properties
2) Stop Alfresco
3) Run the deploy-alfresco-amp ant target
4) Run the deploy-share-jar ant target
5) Start Alfresco


