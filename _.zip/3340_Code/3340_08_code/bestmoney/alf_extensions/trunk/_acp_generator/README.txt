To build the ACP Generator run the ant target package-acpgen-jar
in the build.xml file.

A ready to use jar file can be found in the build/dist directory.


