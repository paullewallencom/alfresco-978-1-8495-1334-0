To build the MobileX application:

1) Install Grails
2) Run: bestmoney\alf_clients\xmobile>grails -Dserver.port=8081 run-app



